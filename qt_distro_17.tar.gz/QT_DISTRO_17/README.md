# solve-quartiles-zsh
# Solve Apple News+ Quartiles Puzzles with Z-shell
# README: README file, ver. 2.6.17
# SCRIPT: solve-quartiles.zsh
# Author: Mike Carney
# email : fixn2fixit@gmail.com
# Date  : May 25, 2026
# 
# PURPOSE
# -------
# Solves Apple News+ Quartiles puzzles
# Avoids human meltdown arranging 123,520 combinations
# Zsh is 30+ years old, it's still capable and fast
# Zsh is the default shell for MacOS and Kali Linux
# Zsh is available to install for most Linux disros.
#
# INSTALL/USE
# -----------
# Zsh must be installed or add that package first (MacOS default, Linux opt)
# Where: wherever you want to use the script, download files there
# Expected typical location is user's $HOME path
# Bundled: solve-quartiles.zsh, wordlist.txt, tiles.txt, tiles.test, README.md
# Download: qt_distro_17.tar.gz
# Extract distro by: tar -xvzf qt_distro_17.tar.gz
# cd QT_DISTRO_17
# Solve puzzles with: zsh solve-quartiles.zsh

# TO PLAY 
# -------
# On Apple News+ Puzzles, find a Quartiles puzzle to solve
# Initial run asks for input (goes into tiles.txt), enter all 20 tiles
# If instead you enter a single period, the current (tiles.txt) file is used
# (tiles.txt) must have (20) tiles total, space-delimited, one or more lines
# Intended/bundled (tiles.test) can be used to copy to (tiles.txt) for demo

# OPTIONAL
# -------- 
# Try an OCR app to scan 20 tiles displayed online (altogether)
# then copy/paste the entire group instead of typing each tile during input 
#
# DEVELOPMENT IDEAS IMPLEMENTED 
# -----------------------------
# No special libraries, no database, nothing exotic
# No OS unique utilities (Linux vs. MacOS)
# Minimized file searches, used memory arrays primarily
# Must input 20 tiles (full tiles space-separated)
# Used standard command-line tools only, shell and regex
# Located a reliable wordplay wordlist from GitHub, etc.
# Included May 24, 2026 wordlist.txt in the install distro
# Because any particular wordlist is likely imperfect,
# (add/del) words as puzzles reveal over days/months, etc.
# wordlist.txt will be updated regularly for this project
# 
# LATER IMPLEMENTED
# -----------------
# Added checks, wordlist compatibility and tiles content
# Sorting tiles by wordlist frequency increased speed in most cases
# 4-tile words found omit their tiles from add'l 4-tile searches 
# The min-max character range [08-16] is based on 700+ solutions 
#
# PROBLEMATIC
# -----------
# Optional OCR scanning is imperfect, can introduce multi-byte chars
# Multi-byte character cleanup is an elusive conundrum
# Wordlists found online for download are predominately DOS formatted
# wordlist.txt gets scrubbed, preserve any originals you overwrite 
# Standard -nix utilities don't play well with CRLF terminated files
# 
# SETTLED ON ZSH OVER BASH
# ------------------------
# zsh is faster, coding is familiar to bash in most respects
# However, zsh array elements count from 1, bash from 0
# I avoided {braces} syntax where possible for simplicity 
# 
# MY DEV KIT
# ----------
# Mac mini, 2018 I7, 64GB, BlackMagic GPU, Sequoia 15
# Beelink SER 7 mini PC, 64GB, Ryzen 7840, Ubuntu  24
#
# BENCHMARKS
# ----------
# Ran puzzles gathered over 700+ days
# MacOS: Intel I7    (1.0)-(4.0) sec, < 1.9 > avg
# Linux: Ryzen 7840  (0.3)-(1.5) sec, < 0.5 > avg
#
